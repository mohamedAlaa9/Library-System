package uls;

import java.io.IOException;
import static java.lang.Character.isDigit;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

public class AddBooks extends javax.swing.JFrame {

    public AddBooks() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    static DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    static LocalDateTime now = LocalDateTime.now();

    public static void addBooks(String callNo, String name, String author, String publisher, String quantity) throws IOException {
        Main.books[Main.countBooks] = new Book(callNo, name, author, publisher, quantity, "0", dtf.format(now));

        Files.write(Paths.get("database_books.txt"),
                ("\n" + Main.books[Main.countBooks].getCallNo() + "," + Main.books[Main.countBooks].getName() + "," + Main.books[Main.countBooks].getAuthor() + "," + Main.books[Main.countBooks].getPublisher()
                        + "," + Main.books[Main.countBooks].getQuantity() + "," + Main.books[Main.countBooks].getIssued() + "," + Main.books[Main.countBooks].getAddedDate()).getBytes(), StandardOpenOption.APPEND);
        Main.countBooks++;
    }

    public static boolean isValidCall(String callno) {
        Pattern callPat = Pattern.compile("^\\D{1}@{1}\\d{3}$");
        boolean b = callPat.matcher(callno).matches();
        for (int i = 0; i < Main.countBooks; i++) {
            if (Main.books[i].getCallNo().trim().equals(callno)) {
                b = false;
            }
        }
        return b;

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        title = new javax.swing.JLabel();
        loginData1 = new javax.swing.JPanel();
        name2 = new javax.swing.JLabel();
        password2 = new javax.swing.JLabel();
        author = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        name3 = new javax.swing.JLabel();
        no = new javax.swing.JTextField();
        name4 = new javax.swing.JLabel();
        name5 = new javax.swing.JLabel();
        publisher = new javax.swing.JTextField();
        quantity = new javax.swing.JTextField();
        bookname = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Librarian Section");

        jPanel1.setBackground(new java.awt.Color(79, 97, 125));

        title.setFont(new java.awt.Font("BankGothic Lt BT", 0, 24)); // NOI18N
        title.setForeground(new java.awt.Color(255, 255, 255));
        title.setText("Add Books");
        title.setToolTipText("");

        loginData1.setBackground(new java.awt.Color(35, 57, 93));
        loginData1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        name2.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name2.setForeground(new java.awt.Color(255, 255, 255));
        name2.setText("Call No:");

        password2.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        password2.setForeground(new java.awt.Color(255, 255, 255));
        password2.setText("Name :");

        author.setText(" ");
        author.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                authorActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(101, 116, 142));
        jButton2.setFont(new java.awt.Font("BankGothic Lt BT", 0, 14)); // NOI18N
        jButton2.setText("Add Book");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(101, 116, 142));
        jButton3.setFont(new java.awt.Font("BankGothic Lt BT", 0, 14)); // NOI18N
        jButton3.setText("Back");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        name3.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name3.setForeground(new java.awt.Color(255, 255, 255));
        name3.setText("Author : ");

        no.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                noActionPerformed(evt);
            }
        });
        no.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                noKeyPressed(evt);
            }
        });

        name4.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name4.setForeground(new java.awt.Color(255, 255, 255));
        name4.setText("Quantity : ");

        name5.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name5.setForeground(new java.awt.Color(255, 255, 255));
        name5.setText("Publisher : ");

        quantity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quantityActionPerformed(evt);
            }
        });
        quantity.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                quantityKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout loginData1Layout = new javax.swing.GroupLayout(loginData1);
        loginData1.setLayout(loginData1Layout);
        loginData1Layout.setHorizontalGroup(
            loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginData1Layout.createSequentialGroup()
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(loginData1Layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(name2)
                            .addComponent(password2)
                            .addComponent(name3)
                            .addComponent(name5)
                            .addComponent(name4))
                        .addGap(51, 51, 51)
                        .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(no)
                            .addComponent(author, javax.swing.GroupLayout.DEFAULT_SIZE, 260, Short.MAX_VALUE)
                            .addComponent(publisher)
                            .addComponent(quantity)
                            .addComponent(bookname)))
                    .addGroup(loginData1Layout.createSequentialGroup()
                        .addGap(162, 162, 162)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(loginData1Layout.createSequentialGroup()
                        .addGap(209, 209, 209)
                        .addComponent(jButton3)))
                .addContainerGap(75, Short.MAX_VALUE))
        );
        loginData1Layout.setVerticalGroup(
            loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginData1Layout.createSequentialGroup()
                .addContainerGap(39, Short.MAX_VALUE)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name2)
                    .addComponent(no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(password2)
                    .addComponent(bookname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(name3)
                    .addComponent(author, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(name5)
                    .addComponent(publisher, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(name4)
                    .addComponent(quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(title)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(loginData1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(38, Short.MAX_VALUE)
                .addComponent(title, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(loginData1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void authorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_authorActionPerformed
    }//GEN-LAST:event_authorActionPerformed

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
    }//GEN-LAST:event_jButton2MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed

        JFrame f = new JFrame();
        String uno = no.getText();
        String uname = bookname.getText();
        String uauthor = author.getText();
        String upublisher = publisher.getText();
        String uquantity = quantity.getText();

        if (isValidCall(uno) && !(no.getText().isEmpty() || bookname.getText().isEmpty() || author.getText().isEmpty() || publisher.getText().isEmpty() || quantity.getText().isEmpty())) {
            try {
                addBooks(uno, uname, uauthor, upublisher, uquantity);

                JOptionPane.showMessageDialog(f, "Book added successfully");

            } catch (IOException ex) {
                Logger.getLogger(AddLibrarian.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (no.getText().isEmpty() || bookname.getText().isEmpty() || author.getText().isEmpty() || publisher.getText().isEmpty() || quantity.getText().isEmpty()) {
            JOptionPane.showMessageDialog(f, "Don't leave an empty field!");
           }//GEN-LAST:event_jButton2ActionPerformed
   
        else if (!isValidCall(uno) && !(no.getText().isEmpty() || bookname.getText().isEmpty() || author.getText().isEmpty() || publisher.getText().isEmpty() || quantity.getText().isEmpty())) {
            JOptionPane.showMessageDialog(f, "Please enter a valid call number! Must be a letter @ a number, i.e. a@890, make sure it's not a repeated  call  number!");
        }

    }
    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
    }//GEN-LAST:event_jButton3MouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        new LibrarianSection().setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void noActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_noActionPerformed

    }//GEN-LAST:event_noActionPerformed

    private void noKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_noKeyPressed

    }//GEN-LAST:event_noKeyPressed

    private void quantityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quantityActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_quantityActionPerformed

    private void quantityKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_quantityKeyPressed
        char c = evt.getKeyChar();
        JFrame f = new JFrame();
        if (Character.isLetter(c)) {
            JOptionPane.showMessageDialog(f, "Please enter numbers only!");
        } else
            quantity.setEditable(true);        // TODO add your handling code here:
    }//GEN-LAST:event_quantityKeyPressed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField author;
    private javax.swing.JTextField bookname;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel loginData1;
    private javax.swing.JLabel name2;
    private javax.swing.JLabel name3;
    private javax.swing.JLabel name4;
    private javax.swing.JLabel name5;
    private javax.swing.JTextField no;
    private javax.swing.JLabel password2;
    private javax.swing.JTextField publisher;
    private javax.swing.JTextField quantity;
    private javax.swing.JLabel title;
    // End of variables declaration//GEN-END:variables
}
