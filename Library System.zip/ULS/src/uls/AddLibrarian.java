package uls;

import java.awt.Frame;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class AddLibrarian extends javax.swing.JFrame {

    public static void addElements(String name, String password, String email, String address, String city, String contactno) throws IOException {
        Main.librarians[Main.countLibrarian] = new Librarian(name, password, email, address, city, contactno);
        File file = new File("database_librarians.txt");
        if (file.length() == 0) {
            Files.write(Paths.get("database_librarians.txt"),
                    (Main.librarians[Main.countLibrarian].getName() + "," + Main.librarians[Main.countLibrarian].getPassword() + "," + Main.librarians[Main.countLibrarian].getEmail() + "," + Main.librarians[Main.countLibrarian].getAddress()
                            + "," + Main.librarians[Main.countLibrarian].getCity() + "," + Main.librarians[Main.countLibrarian].getContactno()).getBytes(), StandardOpenOption.APPEND);
        } else {
            Files.write(Paths.get("database_librarians.txt"),("\n" + Main.librarians[Main.countLibrarian].getName() + "," + Main.librarians[Main.countLibrarian].getPassword() + "," + Main.librarians[Main.countLibrarian].getEmail() + "," + Main.librarians[Main.countLibrarian].getAddress()
                    + "," + Main.librarians[Main.countLibrarian].getCity() + "," + Main.librarians[Main.countLibrarian].getContactno()).getBytes(), StandardOpenOption.APPEND);
          }
       
    Main.countLibrarian++;
    }

    public static boolean isValidMail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."
                + "[a-zA-Z0-9_+&*-]+)*@"
                + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
                + "A-Z]{2,7}$";

        Pattern pat = Pattern.compile(emailRegex);
        if (email == null) {
            return false;
        }
        return pat.matcher(email).matches();
    }

    public static boolean isValidNumber(String number) {
        boolean b = true;
        if (number.isBlank() || number.length() == 1) {
            return false;
        } else if (number.length() != 11 || (number.charAt(0) != '0') || (number.charAt(1) != '1')) {
            b = false;
        }
       /* else if(number.charAt(0)!='0')
        {
            return false;
        }
*/
        return b;

    }
    
        private boolean isValidName(String uname) {
        boolean b = true;
        for (int i = 0; i < Main.countLibrarian; i++) {
            if (uname.equals(Main.librarians[i].getName())) {
                b = false;
            }

        }
        return b;
    }

    public AddLibrarian() {
        initComponents();
        this.setLocationRelativeTo(null);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        loginData = new javax.swing.JPanel();
        name1 = new javax.swing.JLabel();
        password1 = new javax.swing.JLabel();
        passwordField1 = new javax.swing.JPasswordField();
        nameField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jPanel1 = new javax.swing.JPanel();
        title = new javax.swing.JLabel();
        loginData1 = new javax.swing.JPanel();
        name2 = new javax.swing.JLabel();
        password2 = new javax.swing.JLabel();
        password = new javax.swing.JPasswordField();
        mail = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        name3 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        name4 = new javax.swing.JLabel();
        name5 = new javax.swing.JLabel();
        name6 = new javax.swing.JLabel();
        address = new javax.swing.JTextField();
        city = new javax.swing.JTextField();
        contactno = new javax.swing.JTextField();

        loginData.setBackground(new java.awt.Color(35, 57, 93));

        name1.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name1.setForeground(new java.awt.Color(255, 255, 255));
        name1.setText("Name :");

        password1.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        password1.setForeground(new java.awt.Color(255, 255, 255));
        password1.setText("password :");

        passwordField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordField1ActionPerformed(evt);
            }
        });

        nameField1.setText(" ");
        nameField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameField1ActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(101, 116, 142));
        jButton1.setFont(new java.awt.Font("BankGothic Lt BT", 0, 14)); // NOI18N
        jButton1.setText("Login");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jRadioButton1.setBackground(new java.awt.Color(35, 57, 93));
        jRadioButton1.setFont(new java.awt.Font("BankGothic Lt BT", 0, 14)); // NOI18N
        jRadioButton1.setForeground(new java.awt.Color(255, 255, 255));
        jRadioButton1.setText("Admin");

        jRadioButton2.setBackground(new java.awt.Color(35, 57, 93));
        jRadioButton2.setFont(new java.awt.Font("BankGothic Lt BT", 0, 14)); // NOI18N
        jRadioButton2.setForeground(new java.awt.Color(255, 255, 255));
        jRadioButton2.setText("Librarian");
        jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout loginDataLayout = new javax.swing.GroupLayout(loginData);
        loginData.setLayout(loginDataLayout);
        loginDataLayout.setHorizontalGroup(
            loginDataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginDataLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(loginDataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(loginDataLayout.createSequentialGroup()
                        .addComponent(jRadioButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jRadioButton2))
                    .addGroup(loginDataLayout.createSequentialGroup()
                        .addGroup(loginDataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(password1)
                            .addComponent(name1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                        .addGroup(loginDataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nameField1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(passwordField1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(50, Short.MAX_VALUE))
            .addGroup(loginDataLayout.createSequentialGroup()
                .addGap(148, 148, 148)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        loginDataLayout.setVerticalGroup(
            loginDataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginDataLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(loginDataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name1, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(nameField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(loginDataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(password1, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(passwordField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(loginDataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jRadioButton1)
                    .addComponent(jRadioButton2))
                .addGap(26, 26, 26)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(86, 86, 86))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Admin Section");
        setMinimumSize(new java.awt.Dimension(594, 555));
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(79, 97, 125));

        title.setFont(new java.awt.Font("BankGothic Lt BT", 0, 24)); // NOI18N
        title.setForeground(new java.awt.Color(255, 255, 255));
        title.setText("Add Librarian");
        title.setToolTipText("");

        loginData1.setBackground(new java.awt.Color(35, 57, 93));
        loginData1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        name2.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name2.setForeground(new java.awt.Color(255, 255, 255));
        name2.setText("Name :");

        password2.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        password2.setForeground(new java.awt.Color(255, 255, 255));
        password2.setText("password :");

        password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordActionPerformed(evt);
            }
        });

        mail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mailActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(101, 116, 142));
        jButton2.setFont(new java.awt.Font("BankGothic Lt BT", 0, 14)); // NOI18N
        jButton2.setText("Add Librarian");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(101, 116, 142));
        jButton3.setFont(new java.awt.Font("BankGothic Lt BT", 0, 14)); // NOI18N
        jButton3.setText("Back");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        name3.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name3.setForeground(new java.awt.Color(255, 255, 255));
        name3.setText("Email :");

        name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameActionPerformed(evt);
            }
        });

        name4.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name4.setForeground(new java.awt.Color(255, 255, 255));
        name4.setText("City :");

        name5.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name5.setForeground(new java.awt.Color(255, 255, 255));
        name5.setText("Address:");

        name6.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name6.setForeground(new java.awt.Color(255, 255, 255));
        name6.setText("Contact No:");

        city.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cityActionPerformed(evt);
            }
        });

        contactno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contactnoActionPerformed(evt);
            }
        });
        contactno.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                contactnoKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout loginData1Layout = new javax.swing.GroupLayout(loginData1);
        loginData1.setLayout(loginData1Layout);
        loginData1Layout.setHorizontalGroup(
            loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginData1Layout.createSequentialGroup()
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(loginData1Layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(name2)
                            .addComponent(password2)
                            .addComponent(name3)
                            .addComponent(name5)
                            .addComponent(name4)
                            .addComponent(name6))
                        .addGap(46, 46, 46)
                        .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(mail, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(address, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(city, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(contactno, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(password, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(loginData1Layout.createSequentialGroup()
                        .addGap(174, 174, 174)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(loginData1Layout.createSequentialGroup()
                        .addGap(219, 219, 219)
                        .addComponent(jButton3)))
                .addGap(148, 148, 148))
        );
        loginData1Layout.setVerticalGroup(
            loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginData1Layout.createSequentialGroup()
                .addContainerGap(39, Short.MAX_VALUE)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name2)
                    .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(password2)
                    .addComponent(password, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(name3)
                    .addComponent(mail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(name5)
                    .addComponent(address, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(name4)
                    .addComponent(city, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(name6)
                    .addComponent(contactno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(title)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(loginData1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(38, Short.MAX_VALUE)
                .addComponent(title, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(loginData1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void passwordField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordField1ActionPerformed
    }//GEN-LAST:event_passwordField1ActionPerformed

    private void nameField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameField1ActionPerformed
    }//GEN-LAST:event_nameField1ActionPerformed

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
    }//GEN-LAST:event_jButton1MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton2ActionPerformed
    }//GEN-LAST:event_jRadioButton2ActionPerformed

    private void passwordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordActionPerformed
    }//GEN-LAST:event_passwordActionPerformed

    private void mailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mailActionPerformed

    }//GEN-LAST:event_mailActionPerformed

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
    }//GEN-LAST:event_jButton2MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        JFrame f = new JFrame();
        String uname = name.getText();
        String upassword = password.getText();
        String umail = mail.getText();
        String uaddress = address.getText();
        String ucity = city.getText();
        String ucontactno = contactno.getText();
        if (name.getText().isEmpty() || password.getText().isEmpty() || address.getText().isEmpty() || city.getText().isEmpty() || contactno.getText().isEmpty() || mail.getText().isEmpty()) {
            JOptionPane.showMessageDialog(f, "Don't leave an empty field!");
        } else if (!isValidMail(umail) && !name.getText().isEmpty() && !password.getText().isEmpty() && !address.getText().isEmpty() && !city.getText().isEmpty() && !contactno.getText().isEmpty()) {
            JOptionPane.showMessageDialog(f, "Please enter a valid email address!");

        } else if (!isValidNumber(ucontactno) && !name.getText().isEmpty() && !password.getText().isEmpty() && !address.getText().isEmpty() && !city.getText().isEmpty() && !mail.getText().isEmpty()) {
            JOptionPane.showMessageDialog(f, "Please enter a valid contact number! 01XXXXXXXXX (11 digits)");
        }else if (!isValidName(uname) && !name.getText().isEmpty() && !password.getText().isEmpty() && !address.getText().isEmpty() && !city.getText().isEmpty() && !mail.getText().isEmpty()) {
            JOptionPane.showMessageDialog(f, "Please choose another username, "+uname+" already exists.");
        } else if (isValidName(uname)&&isValidMail(umail) && isValidNumber(ucontactno) && !name.getText().isEmpty() && !password.getText().isEmpty() && !address.getText().isEmpty() && !city.getText().isEmpty() && !contactno.getText().isEmpty()) {
            try {
                addElements(uname, upassword, umail, uaddress, ucity, ucontactno);
            } catch (IOException ex) {
                Logger.getLogger(AddLibrarian.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(f, "Librarian added successfully");
        }


    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
    }//GEN-LAST:event_jButton3MouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        new AdminSection().setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameActionPerformed

    }//GEN-LAST:event_nameActionPerformed

    private void contactnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contactnoActionPerformed

    }//GEN-LAST:event_contactnoActionPerformed

    private void contactnoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_contactnoKeyPressed
        char c = evt.getKeyChar();
        JFrame f = new JFrame();
        if (!contactno.getText().isEmpty()) {
            if (Character.isLetter(c)) {
                JOptionPane.showMessageDialog(f, "Please enter numbers only!");
            } else {
                contactno.setEditable(true);
            }
        }

    }//GEN-LAST:event_contactnoKeyPressed

    private void cityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cityActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cityActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField address;
    private javax.swing.JTextField city;
    private javax.swing.JTextField contactno;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JPanel loginData;
    private javax.swing.JPanel loginData1;
    private javax.swing.JTextField mail;
    private javax.swing.JTextField name;
    private javax.swing.JLabel name1;
    private javax.swing.JLabel name2;
    private javax.swing.JLabel name3;
    private javax.swing.JLabel name4;
    private javax.swing.JLabel name5;
    private javax.swing.JLabel name6;
    private javax.swing.JTextField nameField1;
    private javax.swing.JPasswordField password;
    private javax.swing.JLabel password1;
    private javax.swing.JLabel password2;
    private javax.swing.JPasswordField passwordField1;
    private javax.swing.JLabel title;
    // End of variables declaration//GEN-END:variables



}
