package uls;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class AddStudent extends javax.swing.JFrame {

    public AddStudent() {
        initComponents();
        this.setLocationRelativeTo(null);
    }

    public static boolean isValidMail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."
                + "[a-zA-Z0-9_+&*-]+)*@"
                + "(?:[a-zA-Z0-9-]+\\.)+[a-z"
                + "A-Z]{2,7}$";

        Pattern pat = Pattern.compile(emailRegex);
        if (email == null) {
            return false;
        }
        return pat.matcher(email).matches();
    }

public static boolean isValidNumber(String number) {
        boolean b;
        
        if(number.isBlank()||number.length()==1){
            return false;
        }
        else if (number.length() != 11 || number.charAt(0) != '0' || number.charAt(1) != '1') {
            b = false;
        } else {
            b = true;
        }
        return b;

    }


       private boolean isValidName(String uname) {
        boolean b = true;
        for (int i = 0; i < Main.countStudents; i++) {
            if (uname.equals(Main.students[i].getName())) {
                b = false;
            }

        }
        return b;
    }

    public static void addStudent(String name, String password, String id, String email, String address, String city, String contactno) throws IOException {
        Main.students[Main.countStudents] = new Student(name, password, id, email, address, city, contactno);

        Files.write(Paths.get("database_students.txt"),
                ("\n" + Main.students[Main.countStudents].getName() + "," + Main.students[Main.countStudents].getPassword() + "," + Main.students[Main.countStudents].getId() + "," + Main.students[Main.countStudents].getEmail() + "," + Main.students[Main.countStudents].getAddress()
                        + "," + Main.students[Main.countStudents].getCity() + "," + Main.students[Main.countStudents].getContactno()).getBytes(), StandardOpenOption.APPEND);
        Main.countStudents++;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        title = new javax.swing.JLabel();
        loginData1 = new javax.swing.JPanel();
        name2 = new javax.swing.JLabel();
        password2 = new javax.swing.JLabel();
        password = new javax.swing.JPasswordField();
        mail = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        name3 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        name4 = new javax.swing.JLabel();
        name5 = new javax.swing.JLabel();
        name6 = new javax.swing.JLabel();
        address = new javax.swing.JTextField();
        city = new javax.swing.JTextField();
        id = new javax.swing.JTextField();
        name7 = new javax.swing.JLabel();
        contactno = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(79, 97, 125));

        title.setFont(new java.awt.Font("BankGothic Lt BT", 0, 24)); // NOI18N
        title.setForeground(new java.awt.Color(255, 255, 255));
        title.setText("Add Student");
        title.setToolTipText("");

        loginData1.setBackground(new java.awt.Color(35, 57, 93));
        loginData1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        name2.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name2.setForeground(new java.awt.Color(255, 255, 255));
        name2.setText("Name :");

        password2.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        password2.setForeground(new java.awt.Color(255, 255, 255));
        password2.setText("password :");

        password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordActionPerformed(evt);
            }
        });

        mail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mailActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(101, 116, 142));
        jButton2.setFont(new java.awt.Font("BankGothic Lt BT", 0, 14)); // NOI18N
        jButton2.setText("Add Student");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(101, 116, 142));
        jButton3.setFont(new java.awt.Font("BankGothic Lt BT", 0, 14)); // NOI18N
        jButton3.setText("Back");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        name3.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name3.setForeground(new java.awt.Color(255, 255, 255));
        name3.setText("Email :");

        name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameActionPerformed(evt);
            }
        });

        name4.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name4.setForeground(new java.awt.Color(255, 255, 255));
        name4.setText("City :");

        name5.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name5.setForeground(new java.awt.Color(255, 255, 255));
        name5.setText("Address:");

        name6.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name6.setForeground(new java.awt.Color(255, 255, 255));
        name6.setText("Contact No:");

        city.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cityActionPerformed(evt);
            }
        });

        id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idActionPerformed(evt);
            }
        });
        id.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                idKeyPressed(evt);
            }
        });

        name7.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name7.setForeground(new java.awt.Color(255, 255, 255));
        name7.setText("ID :");

        contactno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contactnoActionPerformed(evt);
            }
        });
        contactno.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                contactnoKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout loginData1Layout = new javax.swing.GroupLayout(loginData1);
        loginData1.setLayout(loginData1Layout);
        loginData1Layout.setHorizontalGroup(
            loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginData1Layout.createSequentialGroup()
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(loginData1Layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(name2)
                            .addComponent(password2)
                            .addComponent(name3)
                            .addComponent(name5)
                            .addComponent(name4)
                            .addComponent(name6)
                            .addComponent(name7))
                        .addGap(46, 46, 46)
                        .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(mail, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(address, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(city, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(password, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(id, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(contactno, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(loginData1Layout.createSequentialGroup()
                        .addGap(207, 207, 207)
                        .addComponent(jButton3))
                    .addGroup(loginData1Layout.createSequentialGroup()
                        .addGap(165, 165, 165)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(87, Short.MAX_VALUE))
        );
        loginData1Layout.setVerticalGroup(
            loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginData1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name2)
                    .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(password2)
                    .addComponent(password, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name7)
                    .addComponent(id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(name3)
                    .addComponent(mail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(name5)
                    .addComponent(address, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(name4)
                    .addComponent(city, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name6)
                    .addComponent(contactno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(title)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(loginData1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(38, Short.MAX_VALUE)
                .addComponent(title, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(loginData1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void passwordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordActionPerformed

    }//GEN-LAST:event_passwordActionPerformed

    private void mailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mailActionPerformed

    }//GEN-LAST:event_mailActionPerformed

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked

    }//GEN-LAST:event_jButton2MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        JFrame f = new JFrame();
        String uname = name.getText();
        String upassword = password.getText();
        String uid = id.getText();
        String umail = mail.getText();
        String uaddress = address.getText();
        String ucity = city.getText();
        String ucontactno = contactno.getText();
        if (name.getText().isEmpty() || password.getText().isEmpty() || address.getText().isEmpty() || city.getText().isEmpty() || id.getText().isEmpty() || mail.getText().isEmpty() || uid.isEmpty()) {
            JOptionPane.showMessageDialog(f, "Don't leave an empty field!");
        } else if (isValidName(uname)&&isValidMail(umail) && isValidNumber(ucontactno) && !name.getText().isEmpty() && !password.getText().isEmpty() && !address.getText().isEmpty() && !city.getText().isEmpty() && !id.getText().isEmpty()) {
            try {
                addStudent(uname, upassword, uid, umail, uaddress, ucity, ucontactno);
            } catch (IOException ex) {
                Logger.getLogger(AddLibrarian.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(f, "Student added successfully");
        } else if (!isValidMail(umail) && !name.getText().isEmpty() && !password.getText().isEmpty() && !address.getText().isEmpty() && !city.getText().isEmpty() && !id.getText().isEmpty()) {
            JOptionPane.showMessageDialog(f, "Please enter a valid email address!");

        } else if (!isValidNumber(ucontactno) && !name.getText().isEmpty() && !password.getText().isEmpty() && !address.getText().isEmpty() && !city.getText().isEmpty() && !mail.getText().isEmpty()) {
            JOptionPane.showMessageDialog(f, "Please enter a valid contact number! 01XXXXXXXXX (11 digits)");

        }else if (!isValidName(uname)&&isValidNumber(ucontactno) && !name.getText().isEmpty() && !password.getText().isEmpty() && !address.getText().isEmpty() && !city.getText().isEmpty() && !mail.getText().isEmpty()) {
            JOptionPane.showMessageDialog(f, "Please choose another username, "+uname+" already exists.");

        }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked

    }//GEN-LAST:event_jButton3MouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        new AdminSection().setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameActionPerformed

    }//GEN-LAST:event_nameActionPerformed

    private void cityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cityActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cityActionPerformed

    private void idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idActionPerformed

    }//GEN-LAST:event_idActionPerformed

    private void idKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_idKeyPressed
        char c = evt.getKeyChar();
        JFrame f = new JFrame();
        if (!id.getText().isEmpty()) {
            if (Character.isLetter(c)) {
                JOptionPane.showMessageDialog(f, "Please enter numbers only!");
            } else {
                id.setEditable(true);
            }
        }
    }//GEN-LAST:event_idKeyPressed

    private void contactnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contactnoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_contactnoActionPerformed

    private void contactnoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_contactnoKeyPressed
        char c = evt.getKeyChar();
        JFrame f = new JFrame();
        if (!contactno.getText().isEmpty()) {
            if (Character.isLetter(c)) {
                JOptionPane.showMessageDialog(f, "Please enter numbers only!");
            } else
                contactno.setEditable(true);
        }    }//GEN-LAST:event_contactnoKeyPressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField address;
    private javax.swing.JTextField city;
    private javax.swing.JTextField contactno;
    private javax.swing.JTextField id;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel loginData1;
    private javax.swing.JTextField mail;
    private javax.swing.JTextField name;
    private javax.swing.JLabel name2;
    private javax.swing.JLabel name3;
    private javax.swing.JLabel name4;
    private javax.swing.JLabel name5;
    private javax.swing.JLabel name6;
    private javax.swing.JLabel name7;
    private javax.swing.JPasswordField password;
    private javax.swing.JLabel password2;
    private javax.swing.JLabel title;
    // End of variables declaration//GEN-END:variables
}
