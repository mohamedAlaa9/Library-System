package uls;

public class Book {

    private String callNo;
    private String name;
    private String author;
    private String publisher;
    private String quantity;
    private String issued;
    private String addedDate;

    public Book(String callNo, String name, String author, String publisher, String quantity, String issued, String addedDate) {
        this.callNo = callNo;
        this.name = name;
        this.author = author;
        this.publisher = publisher;
        this.quantity = quantity;
        this.issued = issued;
        this.addedDate = addedDate;
    }

    public String getCallNo() {
        return callNo;
    }

    public String getName() {
        return name;
    }

    public String getAuthor() {
        return author;
    }

    public String getPublisher() {
        return publisher;
    }

    public String getQuantity() {
        return quantity;
    }

    public String getIssued() {
        return issued;
    }

    public String getAddedDate() {
        return addedDate;
    }

    public void setCallNo(String callNo) {
        this.callNo = callNo;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public void setIssued(int issued) {
        String newVal = Integer.toString(issued);
        this.issued = newVal;
    }

    public void setAddedDate(String addedDate) {
        this.addedDate = addedDate;
    }

}
