package uls;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class IssueBook extends javax.swing.JFrame {

    public static void addIssuedBook(String callNo, String name, String id, String contact, String issuedate) throws IOException {
        Main.issuedBooks[Main.countIssuedBooks] = new IssuedBooks(callNo, id, name, contact, issuedate);
        File file = new File("database_issuedBooks.txt");
        if (file.length() == 0) {
            Files.write(Paths.get("database_issuedBooks.txt"),
                    (Main.issuedBooks[Main.countIssuedBooks].getCallNo() + "," + Main.issuedBooks[Main.countIssuedBooks].getID() + "," + Main.issuedBooks[Main.countIssuedBooks].getName() + "," + Main.issuedBooks[Main.countIssuedBooks].getContact()
                            + "," + Main.issuedBooks[Main.countIssuedBooks].getIssuedate()).getBytes(), StandardOpenOption.APPEND);
        } else {
            Files.write(Paths.get("database_issuedBooks.txt"),
                    ("\n" + Main.issuedBooks[Main.countIssuedBooks].getCallNo() + "," + Main.issuedBooks[Main.countIssuedBooks].getID() + "," + Main.issuedBooks[Main.countIssuedBooks].getName() + "," + Main.issuedBooks[Main.countIssuedBooks].getContact()
                            + "," + Main.issuedBooks[Main.countIssuedBooks].getIssuedate()).getBytes(), StandardOpenOption.APPEND);
        }

        Main.countIssuedBooks++;
    }


 public static boolean isValidNumber(String number) {
        boolean b;
        
        if(number.isBlank()||number.length()==1){
            return false;
        }
        else if (number.length() != 11  || (number.charAt(0) != '0') || (number.charAt(1) != '1')) {
     
            b = false;
        } else {
            b = true;
        }
        return b;

    }

    
     public boolean isDate(String dateStr) throws ParseException {

        Pattern DATE_PATTERN = Pattern.compile("^((2000|2400|2800|(19|2[0-9](0[48]|[2468][048]|[13579][26])))-02-29)$"
                + "|^(((19|2[0-9])[0-9]{2})-02-(0[1-9]|1[0-9]|2[0-8]))$"
                + "|^(((19|2[0-9])[0-9]{2})-(0[13578]|10|12)-(0[1-9]|[12][0-9]|3[01]))$"
                + "|^(((19|2[0-9])[0-9]{2})-(0[469]|11)-(0[1-9]|[12][0-9]|30))$");

        boolean b = DATE_PATTERN.matcher(date.getText()).matches();
        if(b==false){
            return false;
        }
        else{ 
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");  
        LocalDateTime today = LocalDateTime.now();  
        String todayDate = dtf.format(today);
          
        if (todayDate.compareTo(dateStr) > 0)
        {
            b = false;
        }
        }
        return b;

    }

    public IssueBook() {
        initComponents();
        this.setLocationRelativeTo(null);

    }

    public boolean isValidIssue(String ucallno, String uid, String uname) throws IOException {
        boolean b = false;
        JFrame g = new JFrame();
        for (int i = 0; i < Main.countStudents; i++) {
            if (Main.students[i].getId().equals(uid) && Main.students[i].getName().equals(uname)) {
                {
                    for (int f = 0; f < Main.countIssuedBooks; f++) {
                        if (Main.issuedBooks[f].getID().equals(uid) && Main.issuedBooks[f].getCallNo().endsWith(ucallno)) {
                            JOptionPane.showMessageDialog(g, "You cannot issue the same book 2 times, " + uname);
                            return false;
                        }
                    }
                }
                for (int j = 0; j < Main.countBooks; j++) {
                    if (Main.books[j].getCallNo().equals(ucallno)) {
                        String issued = Main.books[j].getIssued();
                        int newVal = Integer.parseInt(issued);
                        if ((Integer.parseInt(Main.books[j].getIssued()) == Integer.parseInt(Main.books[j].getQuantity()))) {
                            JFrame f = new JFrame();
                            b = false;
                            JOptionPane.showMessageDialog(f, "This book is not available at the moment.");
                            return false;
                        } else if (Integer.parseInt(Main.books[j].getIssued()) < Integer.parseInt(Main.books[j].getQuantity())) {
                            Main.books[j].setIssued(newVal + 1);
                            ViewBooks newFile = new ViewBooks();
                            newFile.update();
                            b = true;
                            return true;
                        }

                    }
                }
            }

       }
                JOptionPane.showMessageDialog(g, "Please make sure your name and ID match!");
            
        return b;
    }

    public boolean isValidStudent(String uid,String uname) {
        boolean b = true;
        int c = 0;
        for (int i = 0; i < Main.countIssuedBooks; i++) {
            if (Main.issuedBooks[i].getID().equals(uid)&&Main.issuedBooks[i].getName().equals(uname)) {
                c++;
            }
        }
        if (c == 3) {
            b = false;
        }
        return b;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        title = new javax.swing.JLabel();
        loginData1 = new javax.swing.JPanel();
        name2 = new javax.swing.JLabel();
        password2 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        name3 = new javax.swing.JLabel();
        callno = new javax.swing.JTextField();
        name4 = new javax.swing.JLabel();
        name5 = new javax.swing.JLabel();
        contact = new javax.swing.JTextField();
        date = new javax.swing.JTextField();
        id = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(79, 97, 125));

        title.setFont(new java.awt.Font("BankGothic Lt BT", 0, 24)); // NOI18N
        title.setForeground(new java.awt.Color(255, 255, 255));
        title.setText("Issue Books");
        title.setToolTipText("");

        loginData1.setBackground(new java.awt.Color(35, 57, 93));
        loginData1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        name2.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name2.setForeground(new java.awt.Color(255, 255, 255));
        name2.setText("Call no: ");

        password2.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        password2.setForeground(new java.awt.Color(255, 255, 255));
        password2.setText("Student ID:");

        name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(101, 116, 142));
        jButton3.setFont(new java.awt.Font("BankGothic Lt BT", 0, 14)); // NOI18N
        jButton3.setText("Back");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        name3.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name3.setForeground(new java.awt.Color(255, 255, 255));
        name3.setText("Student Name:");

        callno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                callnoActionPerformed(evt);
            }
        });
        callno.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                callnoKeyPressed(evt);
            }
        });

        name4.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name4.setForeground(new java.awt.Color(255, 255, 255));
        name4.setText("Return Date: (YYYY-MM-DD)");

        name5.setFont(new java.awt.Font("BankGothic Lt BT", 0, 18)); // NOI18N
        name5.setForeground(new java.awt.Color(255, 255, 255));
        name5.setText("Student Contact:");

        contact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contactActionPerformed(evt);
            }
        });
        contact.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                contactKeyPressed(evt);
            }
        });

        date.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dateActionPerformed(evt);
            }
        });
        date.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                dateKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                dateKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                dateKeyTyped(evt);
            }
        });

        id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idActionPerformed(evt);
            }
        });
        id.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                idKeyPressed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(101, 116, 142));
        jButton1.setFont(new java.awt.Font("BankGothic Lt BT", 0, 11)); // NOI18N
        jButton1.setText("ISSUE BOOK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout loginData1Layout = new javax.swing.GroupLayout(loginData1);
        loginData1.setLayout(loginData1Layout);
        loginData1Layout.setHorizontalGroup(
            loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginData1Layout.createSequentialGroup()
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(loginData1Layout.createSequentialGroup()
                        .addGap(253, 253, 253)
                        .addComponent(jButton3))
                    .addGroup(loginData1Layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(name2)
                            .addComponent(password2)
                            .addComponent(name3)
                            .addComponent(name5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(name4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(51, 51, 51)
                        .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(callno, javax.swing.GroupLayout.DEFAULT_SIZE, 260, Short.MAX_VALUE)
                            .addComponent(name, javax.swing.GroupLayout.DEFAULT_SIZE, 260, Short.MAX_VALUE)
                            .addComponent(contact, javax.swing.GroupLayout.DEFAULT_SIZE, 260, Short.MAX_VALUE)
                            .addComponent(date, javax.swing.GroupLayout.DEFAULT_SIZE, 260, Short.MAX_VALUE)
                            .addComponent(id)))
                    .addGroup(loginData1Layout.createSequentialGroup()
                        .addGap(228, 228, 228)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(75, Short.MAX_VALUE))
        );
        loginData1Layout.setVerticalGroup(
            loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginData1Layout.createSequentialGroup()
                .addContainerGap(39, Short.MAX_VALUE)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(name2)
                    .addComponent(callno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(password2)
                    .addComponent(id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(name3)
                    .addComponent(name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(name5)
                    .addComponent(contact, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(loginData1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(name4)
                    .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(title)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(loginData1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(38, Short.MAX_VALUE)
                .addComponent(title, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(loginData1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameActionPerformed
    }//GEN-LAST:event_nameActionPerformed


    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
    }//GEN-LAST:event_jButton3MouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        new LibrarianSection().setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void callnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_callnoActionPerformed
    }//GEN-LAST:event_callnoActionPerformed

    private void idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idActionPerformed
    }//GEN-LAST:event_idActionPerformed

    private void idKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_idKeyPressed
        char c = evt.getKeyChar();
        JFrame f = new JFrame();
        if (Character.isLetter(c)) {
            JOptionPane.showMessageDialog(f, "Please enter numbers only!");
        } else
            id.setEditable(true);
    }//GEN-LAST:event_idKeyPressed

    private void contactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contactActionPerformed
    }//GEN-LAST:event_contactActionPerformed

    private void dateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dateActionPerformed


    }//GEN-LAST:event_dateActionPerformed
    @SuppressWarnings("empty-statement")
   
    private void dateKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dateKeyPressed


    }//GEN-LAST:event_dateKeyPressed

    private void contactKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_contactKeyPressed
        char c = evt.getKeyChar();
        JFrame f = new JFrame();
        if (Character.isLetter(c)) {
            contact.setEditable(false);
            JOptionPane.showMessageDialog(f, "Please enter numbers only!");
        } else
            contact.setEditable(true);         // TODO add your handling code here:
    }//GEN-LAST:event_contactKeyPressed

    private void callnoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_callnoKeyPressed
    }//GEN-LAST:event_callnoKeyPressed

    private void dateKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dateKeyReleased
    }//GEN-LAST:event_dateKeyReleased

    private void dateKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_dateKeyTyped
    }//GEN-LAST:event_dateKeyTyped

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        JFrame f = new JFrame();
        String ucallno = callno.getText();
        String uname = name.getText();
        String uid = id.getText();
        String ucontact = contact.getText();
        String udate = date.getText();
        int b = 0;

        if (callno.getText().isEmpty() || name.getText().isEmpty() || id.getText().isEmpty() || contact.getText().isEmpty() || date.getText().isEmpty()) {
            JOptionPane.showMessageDialog(f, "Don't leave an empty field!");
        } else if (!ViewBooks.isValid(callno.getText()) && !name.getText().isEmpty() && !id.getText().isEmpty() && !contact.getText().isEmpty() && !date.getText().isEmpty()) {
            JOptionPane.showMessageDialog(f, "There is no book with this call number, try again!");

        } else try {
            if (!isDate(date.getText())) {

                JOptionPane.showMessageDialog(f, "Please enter a valid date! Take care: The return date can't be a past date.");

            } else if (!isValidNumber(ucontact)) {

                JOptionPane.showMessageDialog(f, "Please enter a valid contact number! 01XXXXXXXXX (11 digits)");

            } else if (!isValidStudent(uid,uname)) {
                JOptionPane.showMessageDialog(f, "Student " + uid + " has already issued the maximum number of books.");

            } else try {
                if (isValidStudent(uid,uname) && isValidNumber(ucontact) && isValidIssue(ucallno, uid, uname) && ViewBooks.isValid(callno.getText()) && !(callno.getText().isEmpty() || name.getText().isEmpty() || id.getText().isEmpty() || contact.getText().isEmpty() || date.getText().isEmpty()) && isDate(date.getText())) {

                    addIssuedBook(ucallno, uname, uid, ucontact, udate);
                    b = 1;
                    JOptionPane.showMessageDialog(f, "Book issued successfully");
                } //else if (b == 0) {
                   // JOptionPane.showMessageDialog(f, "Please make sure your name and ID match!");
               // }
            } catch (IOException ex) {
                Logger.getLogger(IssueBook.class.getName()).log(Level.SEVERE, null, ex);
            } catch (ParseException ex) {
                Logger.getLogger(IssueBook.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ParseException ex) {
            Logger.getLogger(IssueBook.class.getName()).log(Level.SEVERE, null, ex);
        }


    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField callno;
    private javax.swing.JTextField contact;
    private javax.swing.JTextField date;
    private javax.swing.JTextField id;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel loginData1;
    private javax.swing.JTextField name;
    private javax.swing.JLabel name2;
    private javax.swing.JLabel name3;
    private javax.swing.JLabel name4;
    private javax.swing.JLabel name5;
    private javax.swing.JLabel password2;
    private javax.swing.JLabel title;
    // End of variables declaration//GEN-END:variables

}
