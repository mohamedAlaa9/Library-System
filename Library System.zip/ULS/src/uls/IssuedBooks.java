package uls;

public class IssuedBooks {

    private String callNo;
    private String ID;
    private String name;
    private String contact;
    private String issuedate;

    public IssuedBooks(String callNo, String id, String name, String contact, String issuedate) {
        this.callNo = callNo;
        this.ID = id;
        this.name = name;
        this.contact = contact;
        this.issuedate = issuedate;
    }

    public void setCallNo(String callNo) {
        this.callNo = callNo;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public void setIssuedate(String issuedate) {
        this.issuedate = issuedate;
    }

    public String getCallNo() {
        return callNo;
    }

    public String getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public String getContact() {
        return contact;
    }

    public String getIssuedate() {
        return issuedate;
    }

}
