package uls;

public class Librarian {

    private String name;
    private String password;
    private String email;
    private String address;
    private String city;
    private String contactno;

    public void setName(String name) {
        this.name = name;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setContactno(String contactno) {
        this.contactno = contactno;
    }

    public Librarian(String name, String password, String email, String address, String city, String contactno) {
        this.name = name;
        this.password = password;
        this.email = email;
        this.address = address;
        this.city = city;
        this.contactno = contactno;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    public String getCity() {
        return city;
    }

    public String getContactno() {
        return contactno;
    }

}
