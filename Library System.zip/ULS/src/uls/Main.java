package uls;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {

    public static Admin[] admins = new Admin[100];
    public static Librarian[] librarians = new Librarian[100];
    public static Book[] books = new Book[100];
    public static IssuedBooks[] issuedBooks = new IssuedBooks[100];
    public static Student[] students = new Student[100];
    public static int countAdmin = 0;
    public static int countLibrarian = 0;
    public static int countBooks = 0;
    public static int countIssuedBooks = 0;
    public static int countStudents = 0;

    public static void getIssuedBooks() {

        String path = "database_issuedBooks.txt";
        File file = new File(path);
        try {
            try ( Scanner x = new Scanner(file)) {
                while (x.hasNext()) {
                    String line = x.nextLine();
                    String token[] = line.split(",");
                    issuedBooks[countIssuedBooks] = new IssuedBooks(token[0], token[1], token[2], token[3], token[4]);
                    countIssuedBooks++;
                }
            }

        } catch (Exception ex) {
            Logger.getLogger(ViewLibrarian.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void getBooks() {

        String path = "database_books.txt";
        File file = new File(path);
        try {
            Scanner x = new Scanner(file);
            while (x.hasNext()) {
                String line = x.nextLine();
                String token[] = line.split(",");
                books[countBooks] = new Book(token[0], token[1], token[2], token[3], token[4], token[5], token[6]);
                countBooks++;
            }

        } catch (FileNotFoundException ex) {
            Logger.getLogger(ViewLibrarian.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private static void getAdmins() throws FileNotFoundException {
        Scanner x = new Scanner(new File("database_admins.txt"));
        String u, p;
        int i = 0;
        while (x.hasNext()) {
            String line = x.nextLine();
            String tokens[] = line.split(",");
            u = tokens[0];
            p = tokens[1];
            admins[i] = new Admin(u, p);
            i++;
            countAdmin++;
        }

    }

    public static void getLibrarians() throws FileNotFoundException {
        Scanner x = new Scanner(new File("database_librarians.txt"));
        String u, p, e, n, a, c;
        int i = 0;

        while (x.hasNext()) {
            String line = x.nextLine();
            String tokens[] = line.split(",");
            u = tokens[0];
            p = tokens[1];
            e = tokens[2];
            a = tokens[3];
            c = tokens[4];
            n = tokens[5];
            librarians[i] = new Librarian(u, p, e, a, c, n);
            i++;
            countLibrarian++;
        }

    }

    public static void getStudents() throws FileNotFoundException {
        Scanner x = new Scanner(new File("database_students.txt"));
        String u, p, e, n, a, c, id;
        int i = 0;

        while (x.hasNext()) {
            String line = x.nextLine();
            String tokens[] = line.split(",");
            u = tokens[0];
            p = tokens[1];
            id = tokens[2];
            e = tokens[3];
            a = tokens[4];
            c = tokens[5];
            n = tokens[6];
            students[i] = new Student(u, p, id, e, a, c, n);
            i++;
            countStudents++;
        }

    }

    public static void main(String[] args) {

        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    getAdmins();
                    getLibrarians();
                    getBooks();
                    getIssuedBooks();
                    getStudents();
                    new Login().setVisible(true);

                } catch (FileNotFoundException ex) {
                    Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        });
    }

}
