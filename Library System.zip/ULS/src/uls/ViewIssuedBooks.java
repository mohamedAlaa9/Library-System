package uls;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ViewIssuedBooks extends javax.swing.JFrame {

    static boolean result = false;
    static String id;
    static String no;
    static int index = 0;
    static int index2;
    static JFrame f = new JFrame();
   static int count;

    public static void returnItem(String no, String uid) throws IOException {

        DefaultTableModel model = (DefaultTableModel) table1.getModel();
        int x, y;
        String tempStr;
        if (index2 != -1) {
            model.removeRow(index2);
        }
        //deleting from array
        for (int i = index2; (i < Main.countIssuedBooks); i++) {
            Main.issuedBooks[i] = Main.issuedBooks[i + 1];

        }
        Main.countIssuedBooks--;

        try {
            //deleting from file
            try ( FileWriter fw = new FileWriter("database_issuedbooks.txt");  BufferedWriter bw = new BufferedWriter(fw)) {
                model = (DefaultTableModel) table1.getModel();
                x = table1.getRowCount();
                y = table1.getColumnCount();
                for (int i = 0; i < x; i++) {
                    for (int j = 1; j < y; j++) {
                        tempStr = table1.getModel().getValueAt(i, j).toString() + ",";
                        bw.write(tempStr);
                    }
                    if (i < x - 1) {
                        bw.write("\n");

                    }
                }
            }
            {
                for (int j = 0; j < Main.countBooks; j++) {
                    if (Main.books[j].getCallNo().equals(no) && Integer.parseInt(Main.books[j].getIssued()) <= Integer.parseInt(Main.books[j].getQuantity())) {
                        String issued = Main.books[j].getIssued();
                        int newVal = Integer.parseInt(issued);
                        Main.books[j].setIssued(newVal - 1);
                        ViewBooks newFile = new ViewBooks();
                        newFile.update();
                    }
                }

            }

        } catch (IOException ex) {
            Logger.getLogger(ViewLibrarian.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public static boolean check(String BookNumber, String ID) throws ParseException, FileNotFoundException {
        //DefaultTableModel model = (DefaultTableModel)IssuedBooks.getModel();
      result = false;
        if (count == 0) {
            ViewIssuedBooks print = new ViewIssuedBooks();
            print.printData();
        }

        for (index = 0; index < table1.getRowCount(); index++) {
            id = table1.getValueAt(index, 2).toString();
            no = table1.getValueAt(index, 1).toString();
            String returnDate = table1.getValueAt(index, 5).toString().trim();

            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDateTime today = LocalDateTime.now();
            String todayDate = dtf.format(today);            
            
            if (id.trim().equals(ID) && no.trim().equals(BookNumber)) {
                index2 = index;

               //System.out.println("Today Date: "+ todayDate + "\n" + returnDate);
                if (todayDate.compareTo(returnDate) < 0) {
                    JOptionPane.showMessageDialog(f, "Thank you for returning the book early!");

                } else if (todayDate.compareTo(returnDate) > 0) {
                    JOptionPane.showMessageDialog(f, "You have a  penalty to pay! You passed your due date.");

                } else if (todayDate.compareTo(returnDate) == 0) {
                    JOptionPane.showMessageDialog(f, "Thank you for returning on time!");

                }
                result = true;
                return result;

            }
        }
        index = 0;
        return result;

    }

    public void printData() throws FileNotFoundException {
        DefaultTableModel model = (DefaultTableModel) table1.getModel();
        for (int j = 0; j < Main.countIssuedBooks; j++) {
            {
                model.addRow(new Object[]{j + 1, Main.issuedBooks[j].getCallNo(), Main.issuedBooks[j].getID(), Main.issuedBooks[j].getName(), Main.issuedBooks[j].getContact(), Main.issuedBooks[j].getIssuedate()});

            }
        }
    }

    public ViewIssuedBooks() throws FileNotFoundException {
        initComponents();
        this.setLocationRelativeTo(null);
        printData();
        count = 1;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        title2 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        table1 = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(79, 97, 125));

        title2.setFont(new java.awt.Font("BankGothic Lt BT", 0, 24)); // NOI18N
        title2.setForeground(new java.awt.Color(255, 255, 255));
        title2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        title2.setText("View Issued Books");
        title2.setToolTipText("");

        table1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Call number", "Student  ID", "Student Name", "Contact number", "Return Date"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(table1);

        jButton3.setText("Back");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(title2)
                .addGap(126, 126, 126)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
            .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 657, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(title2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 352, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        new LibrarianSection().setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton3ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton3;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane4;
    public static javax.swing.JTable table1;
    private javax.swing.JLabel title2;
    // End of variables declaration//GEN-END:variables
}
